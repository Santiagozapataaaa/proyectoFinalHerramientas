<?php

    class recuperarController{

        static function index()
        {
            include './view/recuperar.php';
        }
    }