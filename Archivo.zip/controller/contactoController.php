<?php

    class contactoController{

        static function index()
        {
            include './view/contacto.php';
        }
    }