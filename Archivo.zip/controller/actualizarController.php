<?php

    class actualizarController{

        static function index()
        {
            include './view/actualizar.php';
        }
    }