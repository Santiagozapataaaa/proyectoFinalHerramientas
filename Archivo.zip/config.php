<?php
    $lista_controladores['inicio'] = 'inicioController';
    $lista_controladores['iniciar_sesion'] = 'loginController';
    $lista_controladores['registrar'] = 'registroController';
    $lista_controladores['producto'] = 'productoController';
    $lista_controladores['contacto'] = 'contactoController';
    $lista_controladores['registro'] = 'registroController';
    $lista_controladores['actualizar'] = 'actualizarController';
    $lista_controladores['uploadfile'] = 'upload-file';
    $lista_controladores['recuperar'] = 'recuperarController';