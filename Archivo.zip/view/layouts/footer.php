        <!-- Contenido -->
        <div class=" footer">
                <div class="container">
                        <div class="row">
                                <div class="col-lg-3">
                                        <h5>Contactenos</h5>
                                        <p>Direccion</p>
                                        <p>Pais</p>
                                        <p>Correo</p>
                                        <p>Whatsapp</p>
                                </div>
                                <div class="col-lg-3">
                                        <h5>Informacion</h5>
                                        <p>Politica de Privacidad</p>
                                        <p>Politica de Reembolso</p>
                                        <p>Politica de Envios</p>
                                        <p>Terminos de Servicio</p>
                                </div>
                                <div class="col-lg-3">
                                        <h5>Cuenta</h5>
                                        <p>Sobre Nosotros</p>
                                        <p>Preguntas Frecuentes</p>
                                        <p>Correo</p>
                                        <p>Contacto</p>
                                </div>
                                <div class="col-lg-3">
                                        <img src="./view/img/Logotipo_fenrir_white.png" alt="">
                                </div>
                        </div>
                        <div class="row">
                                <p><i class="bi bi-c-circle"></i> copyright Fenrir 2022</p>
                        </div>
                </div>
        </div>
        <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.2/dist/js/bootstrap.bundle.min.js" integrity="sha384-OERcA2EqjJCMA+/3y+gxIOqMEjwtxJY7qPCqsdltbNJuaOe923+mo//f6V8Qbsw3" crossorigin="anonymous"></script>
        <script src="./view/js/app.js"></script>
</body>

</html>